Peças originais publicadas no perfil, usadas como fonte deste sistema. Consulte antes de criar algo novo.

- `carrossel-1-capa.png` a `carrossel-5-fechamento.png`: carrossel "O que eu, como psiquiatra, faço para cuidar da minha própria saúde mental?" (1080 × 1440). É a linha principal: areia e marinho.
- `institucional-prazer.png`, `institucional-formacao.png`, `institucional-muitas-pessoas.png`: linha institucional sobre marfim (capturas de tela, menor resolução).
- `educativo-tdah.png`: linha educativa sobre papel (captura de tela).
