# Dr. Tárik Jabour · Design System

Sistema visual do perfil [@dr.tarikjabourpsiquiatra](https://instagram.com/dr.tarikjabourpsiquiatra) para criar carrosséis, cards estáticos e capas de reels com a mesma identidade.

![Exemplo de carrossel](exemplos/carrossel-antidepressivos/visao-geral.png)

| Formato | Tamanho | Classe |
| --- | --- | --- |
| Carrossel (cada lâmina) | 1080 × 1440 | `tj-peca` |
| Card estático | 1080 × 1440 | `tj-peca` |
| Capa de reels | 1080 × 1920 | `tj-peca tj-peca--reels` |

## Estrutura

```
tokens/        tokens.json (fonte da verdade) e tokens.css (variáveis CSS, fontes e estilos de texto)
components/    bundle.css com todas as classes tj- e uma pasta por componente (README + preview.html)
docs/          brand-book.md: voz, cores, tipografia, elementos gráficos, fotografia e grade
fonts/         onde entram os arquivos da Helvetica Now Display (não versionados, veja fonts/README.md)
referencias/   peças originais usadas como base do sistema
exemplos/      carrosséis prontos (HTML + PNG exportado)
scripts/       render.py: exporta cada lâmina de um HTML para PNG
```

## Paleta

| Token | Hex | Uso |
| --- | --- | --- |
| `azul-tarik` | `#00456E` | Destaque de título sobre areia, caixa de destaque |
| `marinho-950` | `#000E1D` | Fundo profundo, cantos dos gradientes |
| `marinho-900` | `#00182C` | Fundo marinho, texto sobre areia |
| `marinho-800` | `#002843` | Centro da vinheta |
| `marinho-600` | `#0C4A73` | Luz do gradiente diagonal |
| `areia` | `#B9B39D` | Fundo claro e destaque sobre marinho |
| `creme` | `#FEF1EC` | Texto claro, réguas e contornos |
| `marfim` | `#FFF9E9` | Fundo da linha institucional |
| `papel` | `#F5EFE1` | Fundo da linha educativa |
| `tinta` | `#0A2647` | Texto sobre marfim e papel |
| `taupe` | `#B4A98D` | Caixa da linha institucional |

## Como criar uma peça

1. Adicione as fontes em `fonts/`.
2. Crie um HTML que carregue `tokens/tokens.css` e `components/bundle.css`.
3. Monte cada lâmina com os componentes (veja `docs/brand-book.md` e `components/*/README.md`):

```html
<div class="tj-peca tj-peca--marinho tj-grao">
  <div class="tj-conteudo tj-conteudo--centro" style="gap:28px">
    <h2 class="tj-titulo">Também priorizo tempo de qualidade com <b class="tj-areia">minha família e meus amigos.</b></h2>
    <span class="tj-pilula">Nem todo momento precisa ser produtivo.</span>
    <p class="tj-corpo-lg">Estar <b>presente, conversar, rir e compartilhar</b> experiências também é uma forma de cuidar da mente.</p>
  </div>
  <div class="tj-trilho tj-trilho--topo"><span>@dr.tarikjabourpsiquiatra</span><span>Dr. Tárik Jabour</span></div>
  <div class="tj-seta"></div>
  <div class="tj-trilho tj-trilho--base"><span>Dr. Tárik Jabour</span><span>@dr.tarikjabourpsiquiatra</span></div>
</div>
```

4. Exporte os PNGs:

```bash
pip install playwright && playwright install chromium
python scripts/render.py exemplos/carrossel-antidepressivos/carrossel.html
```

## Componentes

| Grupo | Componentes |
| --- | --- |
| Fundamentos | Peca (canvas e fundos), Trilho (réguas e assinatura) |
| Texto | Titulo, Pilula |
| Blocos | CaixaDestaque, Arco, Seta, Citacoes, Colchete, Foto |
| Modelos | Carrossel, CapaReels, CardEstatico |

Abra qualquer `components/<Nome>/preview.html` no navegador para ver o componente aplicado.

## Regras rápidas

- Toda peça tem régua de topo e de base com o nome e o @. Margem lateral de 120px.
- Título com tracking fechado (−0.08em) e mistura de pesos: base Regular, destaque em Bold e cor.
- Fundos marinhos sempre em gradiente, com grão (`tj-grao`).
- Carrossel alterna areia e marinho; seta em todas as lâminas menos a última; capa sempre com foto.
- Capa de reels: conteúdo dentro do recorte 3:4 central (y de 240 a 1680).

## Créditos de imagem

A foto da capa do exemplo `carrossel-antidepressivos` é do banco Freepik ("High angle pills container with blue background"), obtida via Magnific, licença gratuita com atribuição: Imagem de Freepik.
