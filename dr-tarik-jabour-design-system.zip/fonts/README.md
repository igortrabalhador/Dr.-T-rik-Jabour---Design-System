# Fontes

O sistema usa **Helvetica Now Display** Regular (400) e Bold (700). Por ser uma fonte comercial licenciada, os arquivos não ficam neste repositório.

Coloque nesta pasta, com estes nomes exatos:

- `HelveticaNowDisplay-Regular.ttf`
- `HelveticaNowDisplay-Bold.ttf`

`tokens/tokens.css` carrega as duas a partir daqui. Sem elas, o navegador cai para Helvetica Neue, Helvetica ou Arial, e o espacejamento dos títulos muda.
