"""Exporta cada lâmina de um HTML de carrossel para PNG em 1080px.

Uso:
    pip install playwright && playwright install chromium
    python scripts/render.py exemplos/carrossel-antidepressivos/carrossel.html

Cada elemento com a classe .tj-peca vira um PNG (lamina-1.png, lamina-2.png...) na mesma pasta do HTML.
"""
import asyncio
import pathlib
import sys

from playwright.async_api import async_playwright


async def main(html_path: str) -> None:
    path = pathlib.Path(html_path).resolve()
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1080, "height": 1920})
        await page.goto(path.as_uri())
        await page.evaluate("document.fonts.ready")
        pecas = await page.query_selector_all(".tj-peca")
        for i, peca in enumerate(pecas, 1):
            out = path.parent / f"lamina-{i}.png"
            await peca.screenshot(path=str(out))
            print(out)
        await browser.close()


if __name__ == "__main__":
    asyncio.run(main(sys.argv[1]))
