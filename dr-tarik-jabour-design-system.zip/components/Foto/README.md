Peças com fotografia: capa do carrossel e apresentação.

```html
<div class="tj-peca tj-peca--foto">
  <img class="tj-foto" src="foto.jpg" alt="">
  <div class="tj-veu"></div>
  ...
</div>
```

- Capa: kicker em `tj-pilula--kicker` + `tj-titulo--capa` no terço superior, palavra final em `tj-azul`.
- Apresentação: título grande na base com eco vazado (`tj-eco`) repetindo a primeira palavra.

O consumidor fornece a foto (1080 × 1440 ou maior, assunto na metade inferior). Nos previews a foto é um espaço reservado cinza.
