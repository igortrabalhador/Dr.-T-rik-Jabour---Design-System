Moldura editorial em L duplo da linha institucional, sobre `marfim`.

`tj-colchete` envolve um parágrafo `tj-corpo` justificado que continua a frase do título ("de Juiz de Fora (UFJF), com residência em Psiquiatria..."). O traço de cima e da direita abraça o texto; o da esquerda e de baixo desce a partir da última linha do título.

O consumidor fornece o parágrafo e o recuo (normalmente `margin-left:440px`). Use só em lâminas de apresentação e credenciais.
