Título da lâmina em Helvetica Now Display com tracking fechado e mistura de pesos.

Classes: `tj-titulo` (96px), `tj-titulo--capa` (112px), `tj-titulo--editorial` (104px, institucional). Dentro, `<b>` vira Bold. Cor de destaque com `tj-azul` (sobre areia) ou `tj-areia` (sobre marinho).

```html
<h2 class="tj-titulo">Cultivo meus<br><b class="tj-azul">relacionamentos.</b></h2>
```

Faça: base Regular em `creme`, uma única expressão de destaque em Bold e cor. Quebre linhas à mão quando a frase pedir ritmo.

Não faça: tudo em Bold, mais de uma cor de destaque no mesmo título, caixa alta, abrir o espacejamento, mais de cinco linhas.

Corpo de apoio: `tj-corpo-lg` (42px, `<b>` nas palavras-chave), `tj-corpo-lg--direita` para bloco alinhado à direita, `tj-sublinhado tj-sublinhado--azul` para o trecho sublinhado.
