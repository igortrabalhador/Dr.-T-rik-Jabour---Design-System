Cápsula de texto curto: kicker de capa, frase de respiro ou pergunta final.

- `tj-pilula`: contorno fino, texto `pilula` (42px). "Nem todo momento precisa ser produtivo."
- `tj-pilula tj-pilula--kicker`: acima do título da capa. "O que eu, como **psiquiatra**, faço para"
- `tj-pilula tj-pilula--areia`: preenchida em `areia`, texto `marinho-900`. Só na última lâmina, para a pergunta ao leitor.

O consumidor fornece o texto (até duas linhas) e a posição dentro de `tj-conteudo`.

Não faça: pílula com mais de duas linhas, duas pílulas na mesma lâmina, pílula areia sobre fundo areia.
