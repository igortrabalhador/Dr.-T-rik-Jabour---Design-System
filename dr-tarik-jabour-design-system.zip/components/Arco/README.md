Contorno fino com cantos de 120px (`radius-arco`) que sangra para fora da peça e abraça o título.

Posicione com `style` (left, top, width, height) em px do canvas:

- `tj-arco tj-arco--u`: aberto à esquerda, cantos arredondados à direita. Sangra pela esquerda (`left:-2px`).
- `tj-arco tj-arco--u-esq`: espelhado, sangra pela direita.
- Degrau: `tj-arco--canto-te` (canto superior direito) + `tj-arco--canto-be` (canto inferior esquerdo), como em "Atividade física".

Faça: deixar pelo menos 60px entre o arco e o texto. Um arco por lâmina.

Não faça: fechar o contorno nos quatro lados, usar em linha institucional ou educativa.
