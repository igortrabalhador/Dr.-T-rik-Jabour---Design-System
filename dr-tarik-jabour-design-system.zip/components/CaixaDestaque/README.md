Bloco de texto que explica o título, com fundo próprio.

- `tj-caixa`: `gradiente-caixa`, `radius-lg`, texto centralizado em `creme`, trecho final em `<b>` (fica `branco`). Usar sobre areia, logo abaixo do título.
- `tj-caixa tj-caixa--taupe`: fundo `taupe`, texto `marfim` alinhado à esquerda. Usar na linha institucional sobre marfim, encaixada atrás de um retrato.

O consumidor fornece até cinco linhas de texto e a largura (normalmente 740px, centrada).

Não faça: caixa sobre marinho (some no fundo), duas caixas na lâmina, ícones dentro.
