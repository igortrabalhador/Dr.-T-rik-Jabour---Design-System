Réguas de topo e base com o nome e o @, presentes em toda peça.

```html
<div class="tj-trilho tj-trilho--topo"><span>@dr.tarikjabourpsiquiatra</span><span>Dr. Tárik Jabour</span></div>
<div class="tj-trilho tj-trilho--base"><span>Dr. Tárik Jabour</span><span>@dr.tarikjabourpsiquiatra</span></div>
```

- Linha do carrossel (areia e marinho): @ à esquerda no topo, nome à esquerda na base.
- Linha institucional (marfim): nome à esquerda no topo e na base.
- A cor acompanha o fundo automaticamente: `creme` a 75% sobre areia, marinho e foto; `tinta` sobre marfim e papel (com `linha-media`).
- Em reels as réguas descem para dentro do recorte 3:4 do grid sozinhas.

Não faça: remover as réguas, trocar o nome por logo, colocar texto entre a régua e a borda.
