Pilha de citações curtas da linha educativa, sobre fundo `papel`.

```html
<div class="tj-citacoes">
  <div class="tj-citacao">“não presta atenção”</div>
  <div class="tj-citacao">“vive no mundo da lua”</div>
</div>
```

Cada `tj-citacao` usa `gradiente-pilula`, `radius-sm`, texto itálico em `marfim`, separadas por `space-2`. De duas a quatro citações, cada uma em uma linha. Use para mitos e frases do senso comum que a lâmina vai desmontar.
