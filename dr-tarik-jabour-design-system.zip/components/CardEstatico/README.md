Card único de 1080 × 1440, mesma grade do carrossel, sem botão de seta.

Use para frases de impacto, avisos e chamadas para consulta. Areia com arco para mensagens informativas; vinheta para reflexões e CTA ("Agende sua consulta pelo **link da bio.**"). Um título, até três linhas de apoio, no máximo uma pílula.
