Modelo de carrossel em cinco lâminas de 1080 × 1440, reproduzindo a sequência de referência.

1. Capa com foto: kicker + título da capa.
2. Areia com arco em degrau, título com destaque azul e caixa de destaque.
3. Marinho diagonal, título centralizado com destaque areia, pílula de contorno e corpo.
4. Areia com arco em U, título à esquerda, corpo à direita com sublinhado.
5. Fechamento em vinheta, título à direita, corpo e pergunta em pílula areia, sem seta.

Para mais lâminas, repita o ritmo areia e marinho entre a capa e o fechamento. Mantenha de 5 a 10 lâminas.
