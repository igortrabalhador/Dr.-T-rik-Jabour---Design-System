A peça é o canvas de 1080px onde tudo é montado: `tj-peca` (1080 × 1440) ou `tj-peca tj-peca--reels` (1080 × 1920).

Fundos: `tj-peca--areia`, `tj-peca--marinho` (gradiente diagonal), `tj-peca--vinheta` (fechamento), `tj-peca--marfim` (institucional), `tj-peca--papel` (educativa) e `tj-peca--foto` (com `<img class="tj-foto">` dentro e `tj-veu` por cima quando precisar de leitura).

Adicione `tj-grao` em todo fundo liso ou gradiente. Não use em fotos.

O consumidor fornece: o fundo, o conteúdo dentro de `tj-conteudo`, as duas réguas (`tj-trilho`) e, se for carrossel, a `tj-seta`.

Não faça: fundos chapados de marinho sem gradiente, outras cores de fundo, peças em outro tamanho de canvas.
