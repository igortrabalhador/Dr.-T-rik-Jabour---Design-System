Capa de reels em 1080 × 1920 (`tj-peca tj-peca--reels`).

O grid do perfil mostra só o recorte 3:4 central (y de 240 a 1680, marcado pelo tracejado no terceiro exemplo). Réguas e conteúdo já ficam dentro dele. Use foto ou marinho, título `tj-titulo--capa` com até quatro linhas e kicker opcional. Sem botão de seta.

Deixe a faixa inferior (abaixo de y=1680) só com fundo: ali entram legenda e botões do Instagram.
