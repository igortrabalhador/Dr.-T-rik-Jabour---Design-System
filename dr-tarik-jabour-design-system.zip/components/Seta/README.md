Botão de seta que indica "deslize para o lado" no carrossel.

`<div class="tj-seta"></div>` dentro da peça. Fica centralizado, com o centro a 225px da borda inferior (`seta-base`), na cor do texto da peça.

Use em todas as lâminas do carrossel, menos a última. Não use em card estático nem em capa de reels. Na linha educativa (papel) e institucional (marfim) ela fica larga automaticamente.
