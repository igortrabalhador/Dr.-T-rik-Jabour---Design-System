Sistema visual do perfil @dr.tarikjabourpsiquiatra no Instagram. Ele cobre três formatos, todos desenhados em canvas de 1080px de largura:

| Formato | Tamanho | Classe |
| --- | --- | --- |
| Carrossel (cada lâmina) | 1080 × 1440 | `tj-peca` |
| Card estático | 1080 × 1440 | `tj-peca` |
| Capa de reels | 1080 × 1920 | `tj-peca tj-peca--reels` |

Todas as medidas de tokens e estilos de texto estão em px desse canvas. Exporte sempre em 1x desse tamanho.

## Voz e conteúdo

- Fale em primeira pessoa, como o próprio Dr. Tárik: "O que eu, como psiquiatra, faço para cuidar da minha própria saúde mental?", "Cultivo meus relacionamentos.", "Sou médico formado pela Universidade Federal...".
- Tom acolhedor, direto e sem jargão. Frases curtas, afirmativas, sempre terminadas com ponto. O objetivo é desmistificar a Psiquiatria: "a Psiquiatria oferece tratamentos seguros, eficazes e capazes de devolver qualidade de vida."
- Converse com quem lê no fechamento: "E você, o que tem feito pela sua saúde mental?". O CTA de agendamento é sempre "Agende sua consulta pelo **link da bio.**"
- Caixa: frase normal (só a primeira letra maiúscula). Siglas em maiúsculas e Bold (**TDAH**). Sem emoji, sem exclamação, sem promessa de cura.
- Ênfase é feita por peso e cor, nunca por caixa alta: a palavra que carrega a ideia vai em Bold e em cor de destaque (`azul-tarik` sobre areia, `areia` sobre marinho).
- Um título por lâmina, no máximo cinco linhas de corpo. Uma ideia por lâmina.

## Tipografia

- Uma única família: **Helvetica Now Display**, Regular (400) e Bold (700), arquivos em `fonts/`. Use `--font-display`.
- Títulos têm entrelinha muito fechada (`titulo`: 96px, 0.92) e espacejamento negativo forte (−0.08em). Essa compressão é a assinatura da marca: não abra o tracking.
- O título mistura pesos dentro da mesma frase: base em Regular, palavras-chave em Bold. Exemplos: "**cuidar** da **minha** própria **saúde mental?**", "Também priorizo tempo de qualidade com **minha família e meus amigos.**"
- Capa: `titulo-capa` (112px). Lâminas internas: `titulo` (96px). Linha institucional: `titulo-editorial` (104 a 124px, tracking −0.04em, Regular, em `tinta`).
- Corpo: `corpo-lg` (42px) nas lâminas de carrossel; `corpo` (32px) só em textos longos da linha institucional. Negrito marca as palavras que resumem a frase.
- Assinatura e @ nas réguas: `assinatura` (28px, Regular).
- Itálico aparece apenas nas pílulas de citação ("não presta atenção"). Não há arquivo itálico: o navegador inclina a Regular. Se houver o arquivo Helvetica Now Display Italic, adicione em `fonts/`.

## Cores

A marca vive em dois polos: **areia** (`areia` #B9B39D) e **marinho** (`marinho-950` a `marinho-600` e `azul-tarik` #00456E), com `creme` (#FEF1EC) como cor de texto clara.

- Sobre areia: título em `creme` Regular + palavra de destaque em `azul-tarik` Bold. Réguas e arcos em `creme` a 75%.
- Sobre marinho: título em `creme` + destaque em `areia` Bold. Corpo em `creme`, palavras-chave em Bold.
- Alterne areia e marinho ao longo do carrossel (capa com foto, areia, marinho, areia, marinho). Nunca duas lâminas marinhas seguidas sem motivo.
- Linha institucional e educativa usa fundos claros: `marfim` (#FFF9E9) ou `papel` (#F5EFE1), com texto, réguas e contornos em `tinta` (#0A2647), e `taupe` (#B4A98D) para caixas.
- Fundos marinhos são sempre gradientes, nunca chapados: `gradiente-diagonal` nas lâminas internas, `gradiente-vinheta` no fechamento e em cards de reflexão.
- Todo fundo liso ou gradiente recebe grão sutil (`tj-grao`, `opacidade-grao`).
- Atenção à leitura: `creme` sobre `areia` tem só 1.9:1. É o par original da marca e fica, mas apenas em títulos grandes (80px ou mais) e sempre acompanhado de uma palavra em `azul-tarik`. Corpo longo sobre areia: prefira deixar em `creme` só se for 42px ou mais e curto; quando a leitura for crítica, use `marinho-900`.

## Elementos gráficos

- **Réguas**: toda peça tem régua superior e inferior de `linha-fina` (1.5px) entre as `margem` (120px). Acima da régua de cima e abaixo da de baixo vão o @ e o nome "Dr. Tárik Jabour", em lados opostos e invertidos entre topo e base. Nunca omita.
- **Botão de seta**: cápsula de 224 × 56px com seta longa, centralizado, centro a 225px da borda inferior (`seta-base`). Em todas as lâminas de carrossel, menos a última. Na linha educativa, versão larga (560px).
- **Pílula de contorno**: retângulo de `radius-md` com contorno de 1.5px. Serve para o kicker da capa e para frases de respiro ("Nem todo momento precisa ser produtivo.").
- **Pílula areia**: preenchida, texto em `marinho-900`, só para a pergunta final.
- **Caixa de destaque**: bloco em `gradiente-caixa` com `radius-lg`, texto centralizado em `creme` e trecho final em Bold `branco`. Uma por lâmina, sobre areia.
- **Arco**: contorno fino com cantos de `radius-arco` (120px) que sangra para fora da peça, envolvendo o título. Variações: U aberto (relacionamentos.), degrau (Atividade física). Um arco por lâmina, no máximo.
- **Pílulas de citação** (linha educativa): blocos `gradiente-pilula` empilhados com `space-2`, texto itálico em `marfim`.
- **Colchete editorial** (linha institucional): duas linhas em L de `linha-media` que encaixam um bloco de texto justificado ao lado do título.
- **Eco vazado**: repetir a palavra do título só com contorno (`tj-eco`), como em "Prazer, Prazer,".
- Não use ícones, emoji, sombras nem cards com borda colorida lateral. Os únicos grafismos são linhas finas, cápsulas e gradientes.

## Fotografia

- Fotos reais do Dr. Tárik ou de objetos do seu dia a dia (o boné "Mental Vacation"), com luz natural, fundo neutro e profundidade de campo rasa.
- Paleta da foto deve conversar com areia e azul: paredes claras, madeira, camisa azul clara, objetos em azul.
- Na capa com foto, o texto fica no terço superior, sobre a área mais limpa, e o objeto ocupa a metade inferior. Aplique `tj-veu` quando o fundo competir com o texto.
- Retratos dentro de layout claro usam `tj-moldura-foto` (`radius-lg`).

## Grade e espaçamento

- Margem lateral fixa de 120px (`margem`) para réguas e textos. Títulos podem recuar até 180px quando estão dentro de um arco.
- Régua superior em y=116 (`regua-topo`), régua inferior em y=1300 (`regua-base` a partir da base). Conteúdo entre y≈200 e y≈1140.
- Capa de reels (1080 × 1920): o grid do perfil mostra só o recorte 3:4 central (y de 240 a 1680). Réguas, título e assinatura ficam dentro desse recorte; o restante recebe só fundo. Sem botão de seta.
- Card estático: mesma grade do carrossel, sem botão de seta.
- Alinhamento: centralizado nas lâminas de marinho, à esquerda nas de areia com arco, à direita no fechamento. Varie dentro do carrossel.

## Como montar uma peça

```html
<div class="tj-peca tj-peca--marinho tj-grao">
  <div class="tj-conteudo tj-conteudo--centro" style="gap:28px">
    <h2 class="tj-titulo">Também priorizo tempo de qualidade com <b class="tj-areia">minha família e meus amigos.</b></h2>
    <span class="tj-pilula">Nem todo momento precisa ser produtivo.</span>
    <p class="tj-corpo-lg">Estar <b>presente, conversar, rir e compartilhar</b> experiências também é uma forma de cuidar da mente.</p>
  </div>
  <div class="tj-trilho tj-trilho--topo"><span>@dr.tarikjabourpsiquiatra</span><span>Dr. Tárik Jabour</span></div>
  <div class="tj-seta"></div>
  <div class="tj-trilho tj-trilho--base"><span>Dr. Tárik Jabour</span><span>@dr.tarikjabourpsiquiatra</span></div>
</div>
```

Carregue `tokens.css`, as fontes e `components/bundle.css`. Os componentes são só HTML e CSS (classes `tj-`), sem JavaScript. Os modelos prontos estão em Carrossel, CapaReels e CardEstatico, e as peças originais de referência no grupo de assets Referencias.
